package solver;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.CommonTreeNodeStream;
import org.antlr.runtime.tree.Tree;
import org.antlr.stringtemplate.StringTemplateGroup;
import org.antlr.stringtemplate.language.AngleBracketTemplateLexer;

public class Main {
    private static final String TEMPLATE_FILE = "template.stg";
    private static final String PUZZLE = "Z:\\win7\\lu-rb-jav\\ChochoCOnstraintSolverTest\\src\\solver\\Raetsel.txt";
    
	public static void main(String[] args) throws RecognitionException,
			FileNotFoundException, IOException {
        AST_SymbolraetselLexer lexer = new AST_SymbolraetselLexer(new ANTLRFileStream(PUZZLE, "UTF8"));
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		AST_SymbolraetselParser parser = new AST_SymbolraetselParser(tokens);
		AST_SymbolraetselParser.prog_return result = parser.prog();
		Tree t = (Tree) result.getTree();
		System.out.println("nach dem parsen");
		System.out.println(t.toStringTree());

		CommonTreeNodeStream nodes = new CommonTreeNodeStream(t);
		nodes.setTokenStream(tokens);
		AST_SymbolRaetsel_Normalisierung normalizer = new AST_SymbolRaetsel_Normalisierung(nodes);
		AST_SymbolRaetsel_Normalisierung.prog_return ast2 = normalizer.prog();
		CommonTree r2 = ((CommonTree) ast2.tree);
		System.out.println("\n\nnach dem normalisieren");
		System.out.println(r2.toStringTree());


		CommonTreeNodeStream nodes2 = new CommonTreeNodeStream(r2);
		nodes2.setTokenStream(tokens);
		SymbolraetselEmitter emitter = new SymbolraetselEmitter(nodes2);
		InputStream templateIs = Main.class.getClassLoader()
				.getResourceAsStream(TEMPLATE_FILE);

		StringTemplateGroup templates = new StringTemplateGroup(
				new InputStreamReader(templateIs, "ISO-8859-15"),
				AngleBracketTemplateLexer.class);
		emitter.setTemplateLib(templates);
		SymbolraetselEmitter.puzzle_return puzzle_return = emitter.puzzle();
		String output = puzzle_return.getTemplate().toString();
		System.out.println("\n\nausgabe");
		System.out.println(output);



	}

}
