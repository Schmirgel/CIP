package solver;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.CommonTreeNodeStream;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;
import org.antlr.stringtemplate.language.AngleBracketTemplateLexer;


public class __Test__ {

//    private static final String TEMPLATE_FILE = "template.stg";
    private static final String TEMPLATE_FILE = "src/solver/template.stg";
    private static final String PUZZLE = "src/solver/Raetsel.txt";
    private static final String PUZZLE2 = "src/symbolpuzzle/puzzles/puzzle1.txt";

    
    public static void main(String args[]) throws Exception {
        
        // Schritt 1: Mittels Grammatik Symbolraetsel.g wird der erste basic CommonTree AST erzeugt
        
        AST_SymbolraetselLexer lex = new AST_SymbolraetselLexer(new ANTLRFileStream(PUZZLE, "UTF8"));
        CommonTokenStream tokens = new CommonTokenStream(lex);

        AST_SymbolraetselParser parser = new AST_SymbolraetselParser(tokens);
        AST_SymbolraetselParser.prog_return r = parser.prog();
        CommonTree ast = (CommonTree)r.getTree(); 

        
        // Schritt 2: Mittels Grammatik Symbolraetsel_Normalisierung.g wird der AST normalisiert und
        // aus allen Minus-Aufgaben werden Plus-Aufgaben gemacht
        
        // Die Knoten vom ersten AST
        CommonTreeNodeStream nodes = new CommonTreeNodeStream(r.getTree()); 
        AST_SymbolRaetsel_Normalisierung walker = new AST_SymbolRaetsel_Normalisierung(nodes);
        AST_SymbolRaetsel_Normalisierung.prog_return r2 = walker.prog();

        
        CommonTree newAST = (CommonTree)r2.getTree(); 
        System.out.println("******* Old AST ********");
        System.out.println(ast.toStringTree());
        
        System.out.println("******* New AST = Normalized ********");
        System.out.println(newAST.toStringTree());
        
        
        // Schritt 3: Mittel Grammatik SymbolRaetselEmitter.g wird der normalisierte AST eingelesen
        // und  
        
        CommonTreeNodeStream nodes2 = new CommonTreeNodeStream(r2.getTree()); // vorher: nur r2
        nodes2.setTokenStream(tokens); // TODO ???
        
        SymbolraetselEmitter emitter = new SymbolraetselEmitter(nodes2);
        
//        InputStream templateIs = Main.class.getClassLoader().getResourceAsStream(TEMPLATE_FILE);
        InputStream templateIs = new FileInputStream(TEMPLATE_FILE);

        StringTemplateGroup templates = new StringTemplateGroup(
                new InputStreamReader(templateIs, "ISO-8859-15"),
                AngleBracketTemplateLexer.class);
        emitter.setTemplateLib(templates);
        
        
//        System.out.println(emitter.getTemplateLib());
        SymbolraetselEmitter.puzzle_return puzzle_return = emitter.puzzle();
        StringTemplate output = (StringTemplate)puzzle_return.getTemplate();
//        System.out.println(output);
        
        
        Puzzle puzzle = new Puzzle();
        puzzle.solve();

//        System.out.println("******* Finale Ausgabe *******");
//        System.out.println(output);

    }

}