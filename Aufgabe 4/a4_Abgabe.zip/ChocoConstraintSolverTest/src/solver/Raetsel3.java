//Package
package solver;

//Choco Constraint Solver
import choco.Choco;
import choco.Options;
import choco.cp.model.CPModel;
import choco.cp.solver.CPSolver;
import choco.kernel.model.Model;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.Solver;

public class Raetsel3 {

  private static final IntegerVariable ZERO = Choco.constant(0);

  /**
   * Loesen des Zahlenraetsels
   */
  public static void solve() {
      long start = System.nanoTime();
    // Build model
    Model model = new CPModel();
    
    // Declare every letter as a variable
    IntegerVariable A = Choco.makeIntVar("A", 0, 9, Options.V_ENUM); 
    IntegerVariable B = Choco.makeIntVar("B", 0, 9, Options.V_ENUM); 
    IntegerVariable C = Choco.makeIntVar("C", 0, 9, Options.V_ENUM); 
    IntegerVariable D = Choco.makeIntVar("D", 0, 9, Options.V_ENUM); 
    IntegerVariable E = Choco.makeIntVar("E", 0, 9, Options.V_ENUM); 
    IntegerVariable F = Choco.makeIntVar("F", 0, 9, Options.V_ENUM); 
    IntegerVariable G = Choco.makeIntVar("G", 0, 9, Options.V_ENUM); 
    IntegerVariable H = Choco.makeIntVar("H", 0, 9, Options.V_ENUM); 
    IntegerVariable J = Choco.makeIntVar("J", 0, 9, Options.V_ENUM); 
    IntegerVariable K = Choco.makeIntVar("K", 0, 9, Options.V_ENUM); 
    
    //Uebertraege
    IntegerVariable u1 = Choco.makeIntVar("u0", 0, 1, Options.V_ENUM);
    IntegerVariable u2 = Choco.makeIntVar("u1", 0, 1, Options.V_ENUM);
    IntegerVariable u3 = Choco.makeIntVar("u2", 0, 1, Options.V_ENUM);
    IntegerVariable u4 = Choco.makeIntVar("u3", 0, 1, Options.V_ENUM);
    IntegerVariable u5 = Choco.makeIntVar("u4", 0, 1, Options.V_ENUM);
    IntegerVariable u6 = Choco.makeIntVar("u5", 0, 1, Options.V_ENUM);
    IntegerVariable u7 = Choco.makeIntVar("u6", 0, 1, Options.V_ENUM);
    IntegerVariable u8 = Choco.makeIntVar("u7", 0, 1, Options.V_ENUM);
    IntegerVariable u9 = Choco.makeIntVar("u8", 0, 1, Options.V_ENUM);
    IntegerVariable u10 = Choco.makeIntVar("u9", 0, 1, Options.V_ENUM);
    IntegerVariable u11 = Choco.makeIntVar("u10", 0, 1, Options.V_ENUM);
    IntegerVariable u12 = Choco.makeIntVar("u11", 0, 1, Options.V_ENUM);
    IntegerVariable u13 = Choco.makeIntVar("u12", 0, 1, Options.V_ENUM);
    IntegerVariable u14 = Choco.makeIntVar("u13", 0, 1, Options.V_ENUM);
    IntegerVariable u15 = Choco.makeIntVar("u14", 0, 1, Options.V_ENUM);
    IntegerVariable u16 = Choco.makeIntVar("u15", 0, 1, Options.V_ENUM);
    IntegerVariable u17 = Choco.makeIntVar("u16", 0, 1, Options.V_ENUM);
    IntegerVariable u18 = Choco.makeIntVar("u17", 0, 1, Options.V_ENUM);
    IntegerVariable u19 = Choco.makeIntVar("u18", 0, 1, Options.V_ENUM);
    IntegerVariable u20 = Choco.makeIntVar("u19", 0, 1, Options.V_ENUM);
    IntegerVariable u21 = Choco.makeIntVar("u20", 0, 1, Options.V_ENUM);
    IntegerVariable u22 = Choco.makeIntVar("u21", 0, 1, Options.V_ENUM);
    IntegerVariable u23 = Choco.makeIntVar("u22", 0, 1, Options.V_ENUM);
    IntegerVariable u24 = Choco.makeIntVar("u23", 0, 1, Options.V_ENUM);
 

    u1 = (IntegerVariable) Choco.sum(G, A);
    model.addConstraint(Choco.eq(G, Choco.mod(u1, 10)));

    u2 = (IntegerVariable)Choco.sum(D, E, Choco.div(u1, 10));
    model.addConstraint(Choco.eq(G, Choco.mod(u2, 10)));

    u3 = (IntegerVariable)Choco.sum(G, E, Choco.div(u2, 10));
    model.addConstraint(Choco.eq(A, Choco.mod(u3, 10)));

    u4 = (IntegerVariable)Choco.sum(B, B, Choco.div(u3, 10));
    model.addConstraint(Choco.eq(C, Choco.mod(u4, 10)));

    u5 = (IntegerVariable)Choco.sum(G, K, Choco.div(u4, 10));
    model.addConstraint(Choco.eq(F, Choco.mod(u5, 10)));

    u6 = (IntegerVariable)Choco.sum(H, D, Choco.div(u5, 10));
    model.addConstraint(Choco.eq(A, Choco.mod(u6, 10)));

    u7 = (IntegerVariable)Choco.sum(A, J, Choco.div(u6, 10));
    model.addConstraint(Choco.eq(K, Choco.mod(u7, 10)));

    u8 = (IntegerVariable)Choco.sum(C, ZERO, Choco.div(u7, 10));
    model.addConstraint(Choco.eq(C, Choco.mod(u8, 10)));

    u9 = (IntegerVariable)Choco.sum(B, B, Choco.div(u8, 10));
    model.addConstraint(Choco.eq(D, Choco.mod(u9, 10)));

    u10 = (IntegerVariable)Choco.sum(C, B, Choco.div(u9, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(u10, 10)));

    u11 = (IntegerVariable)Choco.sum(F, G, Choco.div(u10, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(u11, 10)));

    u12 = (IntegerVariable)Choco.sum(F, ZERO, Choco.div(u11, 10));
    model.addConstraint(Choco.eq(G, Choco.mod(u12, 10)));

    u13 = (IntegerVariable)Choco.sum(G, F, Choco.div(u12, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(u13, 10)));

    u14 = (IntegerVariable)Choco.sum(D, A, Choco.div(u13, 10));
    model.addConstraint(Choco.eq(C, Choco.mod(u14, 10)));

    u15 = (IntegerVariable)Choco.sum(G, K, Choco.div(u14, 10));
    model.addConstraint(Choco.eq(F, Choco.mod(u15, 10)));

    u16 = (IntegerVariable)Choco.sum(B, C, Choco.div(u15, 10));
    model.addConstraint(Choco.eq(F, Choco.mod(u16, 10)));

    u17 = (IntegerVariable)Choco.sum(B, K, Choco.div(u16, 10));
    model.addConstraint(Choco.eq(A, Choco.mod(u17, 10)));

    u18 = (IntegerVariable)Choco.sum(B, D, Choco.div(u17, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(u18, 10)));

    u19 = (IntegerVariable)Choco.sum(G, J, Choco.div(u18, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(u19, 10)));

    u20 = (IntegerVariable)Choco.sum(ZERO, ZERO, Choco.div(u19, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(u20, 10)));

    u21 = (IntegerVariable)Choco.sum(G, G, Choco.div(u20, 10));
    model.addConstraint(Choco.eq(D, Choco.mod(u21, 10)));

    u22 = (IntegerVariable)Choco.sum(G, H, Choco.div(u21, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(u22, 10)));

    u23 = (IntegerVariable)Choco.sum(A, A, Choco.div(u22, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(u23, 10)));

    u24 = (IntegerVariable)Choco.sum(C, C, Choco.div(u23, 10));
    model.addConstraint(Choco.eq(G, Choco.mod(u24, 10)));
    
    // Add constraint of all different letters  
    model.addConstraint(Choco.allDifferent(A, B, C, D, E, F, G, H, J, K));    
    
    // Build a solver, read the model and solve it
    Solver s = new CPSolver();
    s.read(model);
    s.solve();
    
    long end = System.nanoTime();
    
    System.out.println("Laufzeit: " + ((end-start)/1000000));
    
    // Print symbol values
    System.out.println("A = " + s.getVar(A).getVal() + ", " + "B = " + s.getVar(B).getVal() + ", " + "C = " + s.getVar(C).getVal() + ", " + "D = " + s.getVar(D).getVal() + ", " + "E = " + s.getVar(E).getVal() + ", " + "F = " + s.getVar(F).getVal() + ", " + "G = " + s.getVar(G).getVal() + ", " + "H = " + s.getVar(H).getVal() + ", " + "J = " + s.getVar(J).getVal() + ", " + "K = " + s.getVar(K).getVal());
 
  }
  
  public static void main(String[] args){
    System.out.println("******* Finale Ausgabe *******");
  	Raetsel.solve();
  }
}
