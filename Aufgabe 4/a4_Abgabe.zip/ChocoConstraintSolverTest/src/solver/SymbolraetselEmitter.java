// $ANTLR 3.4 Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g 2016-01-18 10:25:01
package solver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.antlr.runtime.BitSet;
import org.antlr.runtime.EarlyExitException;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.RecognizerSharedState;
import org.antlr.runtime.RuleReturnScope;
import org.antlr.runtime.Token;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.TreeNodeStream;
import org.antlr.runtime.tree.TreeParser;
import org.antlr.runtime.tree.TreeRuleReturnScope;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;
import org.antlr.stringtemplate.language.AngleBracketTemplateLexer;
@SuppressWarnings({"all", "warnings", "unchecked"})
public class SymbolraetselEmitter extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "A", "B", "BUCHSTABEN", "C", "D", "E", "EQ", "F", "G", "H", "I", "J", "K", "L", "M", "MINUS", "N", "O", "P", "PLUS", "Q", "R", "S", "T", "U", "V", "W", "WORD", "WS", "X", "Y", "Z", "PUZZLE"
    };

    public static final int EOF=-1;
    public static final int A=4;
    public static final int B=5;
    public static final int BUCHSTABEN=6;
    public static final int C=7;
    public static final int D=8;
    public static final int E=9;
    public static final int EQ=10;
    public static final int F=11;
    public static final int G=12;
    public static final int H=13;
    public static final int I=14;
    public static final int J=15;
    public static final int K=16;
    public static final int L=17;
    public static final int M=18;
    public static final int MINUS=19;
    public static final int N=20;
    public static final int O=21;
    public static final int P=22;
    public static final int PLUS=23;
    public static final int Q=24;
    public static final int R=25;
    public static final int S=26;
    public static final int T=27;
    public static final int U=28;
    public static final int V=29;
    public static final int W=30;
    public static final int WORD=31;
    public static final int WS=32;
    public static final int X=33;
    public static final int Y=34;
    public static final int Z=35;
    public static final int PUZZLE=36;

    // delegates
    public TreeParser[] getDelegates() {
        return new TreeParser[] {};
    }

    // delegators


    public SymbolraetselEmitter(TreeNodeStream input) {
        this(input, new RecognizerSharedState());
    }
    public SymbolraetselEmitter(TreeNodeStream input, RecognizerSharedState state) {
        super(input, state);
    }

protected StringTemplateGroup templateLib =
  new StringTemplateGroup("SymbolraetselEmitterTemplates", AngleBracketTemplateLexer.class);

public void setTemplateLib(StringTemplateGroup templateLib) {
  this.templateLib = templateLib;
}
public StringTemplateGroup getTemplateLib() {
  return templateLib;
}
/** allows convenient multi-value initialization:
 *  "new STAttrMap().put(...).put(...)"
 */
public static class STAttrMap extends HashMap {
  public STAttrMap put(String attrName, Object value) {
    super.put(attrName, value);
    return this;
  }
  public STAttrMap put(String attrName, int value) {
    super.put(attrName, new Integer(value));
    return this;
  }
}
    public String[] getTokenNames() { return SymbolraetselEmitter.tokenNames; }
    public String getGrammarFileName() { return "src/solver/SymbolraetselEmitter.g"; }


    Set<Character> symbols = new HashSet<Character>();


    public static class puzzle_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "puzzle"
    // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:31:1: puzzle : ^( PUZZLE (constraints+= constraint )* ) -> puzzle(symbols=symbolsconstraints=$constraints);
    public final SymbolraetselEmitter.puzzle_return puzzle() throws RecognitionException {
        SymbolraetselEmitter.puzzle_return retval = new SymbolraetselEmitter.puzzle_return();
        retval.start = input.LT(1);


        List list_constraints=null;
        RuleReturnScope constraints = null;
        try {
            // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:32:3: ( ^( PUZZLE (constraints+= constraint )* ) -> puzzle(symbols=symbolsconstraints=$constraints))
            // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:32:5: ^( PUZZLE (constraints+= constraint )* )
            {
            match(input,PUZZLE,FOLLOW_PUZZLE_in_puzzle67); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:32:25: (constraints+= constraint )*
                loop1:
                do {
                    int alt1=2;
                    int LA1_0 = input.LA(1);

                    if ( (LA1_0==EQ) ) {
                        alt1=1;
                    }


                    switch (alt1) {
                	case 1 :
                	    // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:32:25: constraints+= constraint
                	    {
                	    pushFollow(FOLLOW_constraint_in_puzzle71);
                	    constraints=constraint();

                	    state._fsp--;

                	    if (list_constraints==null) list_constraints=new ArrayList();
                	    list_constraints.add(constraints.getTemplate());


                	    }
                	    break;

                	default :
                	    break loop1;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }


            // TEMPLATE REWRITE
            // 33:5: -> puzzle(symbols=symbolsconstraints=$constraints)
            {
                retval.st = templateLib.getInstanceOf("puzzle",new STAttrMap().put("symbols", symbols).put("constraints", list_constraints));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "puzzle"


    public static class constraint_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "constraint"
    // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:36:1: constraint : ^( EQ ^( PLUS n1= number n2= number ) n3= number ) -> constraint(number1=$n1.numbernumber2=$n2.numbernumber3=$n3.number);
    public final SymbolraetselEmitter.constraint_return constraint() throws RecognitionException {
        SymbolraetselEmitter.constraint_return retval = new SymbolraetselEmitter.constraint_return();
        retval.start = input.LT(1);


        SymbolraetselEmitter.number_return n1 =null;

        SymbolraetselEmitter.number_return n2 =null;

        SymbolraetselEmitter.number_return n3 =null;


        try {
            // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:44:3: ( ^( EQ ^( PLUS n1= number n2= number ) n3= number ) -> constraint(number1=$n1.numbernumber2=$n2.numbernumber3=$n3.number))
            // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:44:5: ^( EQ ^( PLUS n1= number n2= number ) n3= number )
            {
            match(input,EQ,FOLLOW_EQ_in_constraint110); 

            match(input, Token.DOWN, null); 
            match(input,PLUS,FOLLOW_PLUS_in_constraint113); 

            match(input, Token.DOWN, null); 
            pushFollow(FOLLOW_number_in_constraint117);
            n1=number();

            state._fsp--;


            pushFollow(FOLLOW_number_in_constraint121);
            n2=number();

            state._fsp--;


            match(input, Token.UP, null); 


            pushFollow(FOLLOW_number_in_constraint126);
            n3=number();

            state._fsp--;


            match(input, Token.UP, null); 


            // TEMPLATE REWRITE
            // 45:5: -> constraint(number1=$n1.numbernumber2=$n2.numbernumber3=$n3.number)
            {
                retval.st = templateLib.getInstanceOf("constraint",new STAttrMap().put("number1", (n1!=null?n1.number:null)).put("number2", (n2!=null?n2.number:null)).put("number3", (n3!=null?n3.number:null)));
            }



            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "constraint"


    public static class number_return extends TreeRuleReturnScope {
        public Number number;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "number"
    // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:48:1: number returns [Number number] : ^( WORD (syms+= BUCHSTABEN )+ ) ;
    public final SymbolraetselEmitter.number_return number() throws RecognitionException {
        SymbolraetselEmitter.number_return retval = new SymbolraetselEmitter.number_return();
        retval.start = input.LT(1);


        CommonTree syms=null;
        List list_syms=null;

        try {
            // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:54:3: ( ^( WORD (syms+= BUCHSTABEN )+ ) )
            // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:54:5: ^( WORD (syms+= BUCHSTABEN )+ )
            {
            match(input,WORD,FOLLOW_WORD_in_number173); 

            match(input, Token.DOWN, null); 
            // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:54:16: (syms+= BUCHSTABEN )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==BUCHSTABEN) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // Z:\\pub\\Semester 4\\CIP\\Aufgabe 4\\SymbolraetselEmitter.g:54:16: syms+= BUCHSTABEN
            	    {
            	    syms=(CommonTree)match(input,BUCHSTABEN,FOLLOW_BUCHSTABEN_in_number177); 
            	    if (list_syms==null) list_syms=new ArrayList();
            	    list_syms.add(syms);


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            match(input, Token.UP, null); 


            }


            retval.number = new Number();
            retval.number.setDigits(list_syms);
            symbols.addAll(retval.number.getCharacters());

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "number"

    // Delegated rules


 

    public static final BitSet FOLLOW_PUZZLE_in_puzzle67 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_constraint_in_puzzle71 = new BitSet(new long[]{0x0000000000000408L});
    public static final BitSet FOLLOW_EQ_in_constraint110 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_PLUS_in_constraint113 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_number_in_constraint117 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_number_in_constraint121 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_number_in_constraint126 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WORD_in_number173 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BUCHSTABEN_in_number177 = new BitSet(new long[]{0x0000000000000048L});

}