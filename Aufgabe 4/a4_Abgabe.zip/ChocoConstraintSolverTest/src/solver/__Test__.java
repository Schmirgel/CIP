package solver;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.CommonTreeNodeStream;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;
import org.antlr.stringtemplate.language.AngleBracketTemplateLexer;


public class __Test__ {

//    private static final String TEMPLATE_FILE = "template.stg";
    private static final String TEMPLATE_FILE = "src/solver/template.stg";
    private static final String PUZZLE = "src/solver/Raetsel.txt";
    
    public static void main(String args[]) throws Exception {
        
        // Schritt 1: Mittels Grammatik Symbolraetsel.g wird der erste basic CommonTree AST erzeugt
        
        // Der Lexer checkt nur, ob die Eingabe lexikalisch richtig ist.
        AST_SymbolraetselLexer lex = new AST_SymbolraetselLexer(new ANTLRFileStream(PUZZLE, "UTF8"));
        // Der CommonTokenStream erzeugt dann die Token, die der Parser anschließend zum Parsen benötigt
        CommonTokenStream tokens = new CommonTokenStream(lex);
        // Der Parser erhält als Eingabe die Tokens
        AST_SymbolraetselParser parser = new AST_SymbolraetselParser(tokens);
        // Hier wird die Startregel aufgerufen und somit der Rekursive Abstieg initialisiert.
        AST_SymbolraetselParser.prog_return r = parser.prog();
        // Der AST wird auf die Klasse CommonTree gecastet
        CommonTree ast = (CommonTree)r.getTree(); 

        
        // Schritt 2: Mittels Grammatik Symbolraetsel_Normalisierung.g wird der AST normalisiert und
        // aus allen Minus-Aufgaben werden Plus-Aufgaben gemacht
        
        // Nachfolgend werden für den Baumparser alle Knoten vom ersten AST benötigt
        CommonTreeNodeStream nodes = new CommonTreeNodeStream(r.getTree()); 
        AST_SymbolRaetsel_Normalisierung walker = new AST_SymbolRaetsel_Normalisierung(nodes);
        // Hier wird die neue Startregel prog aufgerufen und der Rekursive Abstieg beginnt ebenfalls erneut
        AST_SymbolRaetsel_Normalisierung.prog_return r2 = walker.prog();
        CommonTree newAST = (CommonTree)r2.getTree(); 

        
        System.out.println("******* Old AST ********");
        System.out.println(ast.toStringTree());
        
        System.out.println("******* New AST = Normalized ********");
        System.out.println(newAST.toStringTree());
        
        
        // Schritt 3: Mittels Grammatik SymbolRaetselEmitter.g wird der normalisierte AST eingelesen
        // und aus den 6 einzelnen Aufgaben werden 6 Constraints mittels des String-Templates generiert.
        
        CommonTreeNodeStream nodes2 = new CommonTreeNodeStream(r2.getTree()); // vorher: nur r2
        // Erzeugt auf Basis des normalisierten AST die Emitter Klasse
        SymbolraetselEmitter emitter = new SymbolraetselEmitter(nodes2);
        // Erzeugt den InputStream für das Template
        InputStream templateIs = new FileInputStream(TEMPLATE_FILE);

        StringTemplateGroup templates = new StringTemplateGroup(
                new InputStreamReader(templateIs, "ISO-8859-15"),
                AngleBracketTemplateLexer.class);
        // Teilt dem Emitter mit welches Template verwendet werden soll
        emitter.setTemplateLib(templates);
        
        // Startet die puzzle Methode
        SymbolraetselEmitter.puzzle_return puzzle_return = emitter.puzzle();
        
        // Hier wird das fertige StringTemplate aus dem puzzle_return gelesen.
        // Output enthält jetzt den Text der Raetsel-Java-Klasse
        // Alle Choco-Komponenten, die die Variablen definieren und die Constraints beschreiben,
        // wurden hinzugefügt.
        StringTemplate output = (StringTemplate)puzzle_return.getTemplate();
        
        // Erzeugt die Java-Klasse
        PrintWriter resultWriterClass = new PrintWriter("src/solver/Raetsel.java","UTF-8");
        resultWriterClass.print(output);
        resultWriterClass.close();
    }

}