//Package
package solver;

//Choco Constraint Solver
import choco.Choco;
import choco.Options;
import choco.cp.model.CPModel;
import choco.cp.solver.CPSolver;
import choco.kernel.model.Model;
import choco.kernel.model.variables.integer.IntegerExpressionVariable;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.Solver;

public class Raetsel {

  private static final IntegerVariable ZERO = Choco.constant(0);

  /**
   * Loesen des Zahlenraetsels
   */
  public static void solve() {
      long start = System.nanoTime();
      
    // Build model
    Model model = new CPModel();
    
    // Declare every letter as a variable
    IntegerVariable A = Choco.makeIntVar("A", 0, 9, Options.V_ENUM); 
    IntegerVariable B = Choco.makeIntVar("B", 0, 9, Options.V_ENUM); 
    IntegerVariable C = Choco.makeIntVar("C", 0, 9, Options.V_ENUM); 
    IntegerVariable D = Choco.makeIntVar("D", 0, 9, Options.V_ENUM); 
    IntegerVariable E = Choco.makeIntVar("E", 0, 9, Options.V_ENUM); 
    IntegerVariable F = Choco.makeIntVar("F", 0, 9, Options.V_ENUM); 
    IntegerVariable G = Choco.makeIntVar("G", 0, 9, Options.V_ENUM); 
    IntegerVariable H = Choco.makeIntVar("H", 0, 9, Options.V_ENUM); 
    IntegerVariable J = Choco.makeIntVar("J", 0, 9, Options.V_ENUM); 
    IntegerVariable K = Choco.makeIntVar("K", 0, 9, Options.V_ENUM); 
    
    
    
    
    
    // Add constraint by term
    IntegerExpressionVariable carry = ZERO;

    carry = Choco.sum(G, A, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(G, Choco.mod(carry, 10)));

    carry = Choco.sum(D, E, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(G, Choco.mod(carry, 10)));

    carry = Choco.sum(G, E, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(A, Choco.mod(carry, 10)));

    carry = Choco.sum(B, B, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(C, Choco.mod(carry, 10)));

    carry = ZERO;

    carry = Choco.sum(G, K, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(F, Choco.mod(carry, 10)));

    carry = Choco.sum(H, D, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(A, Choco.mod(carry, 10)));

    carry = Choco.sum(A, J, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(K, Choco.mod(carry, 10)));

    carry = Choco.sum(C, ZERO, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(C, Choco.mod(carry, 10)));

    carry = ZERO;

    carry = Choco.sum(B, B, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(D, Choco.mod(carry, 10)));

    carry = Choco.sum(C, B, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(carry, 10)));

    carry = Choco.sum(F, G, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(carry, 10)));

    carry = Choco.sum(F, ZERO, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(G, Choco.mod(carry, 10)));

    carry = ZERO;

    carry = Choco.sum(G, F, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(carry, 10)));

    carry = Choco.sum(D, A, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(C, Choco.mod(carry, 10)));

    carry = Choco.sum(G, K, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(F, Choco.mod(carry, 10)));

    carry = Choco.sum(B, C, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(F, Choco.mod(carry, 10)));

    carry = ZERO;

    carry = Choco.sum(B, K, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(A, Choco.mod(carry, 10)));

    carry = Choco.sum(B, D, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(carry, 10)));

    carry = Choco.sum(G, J, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(carry, 10)));

    carry = Choco.sum(ZERO, ZERO, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(carry, 10)));

    carry = ZERO;

    carry = Choco.sum(G, G, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(D, Choco.mod(carry, 10)));

    carry = Choco.sum(G, H, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(E, Choco.mod(carry, 10)));

    carry = Choco.sum(A, A, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(B, Choco.mod(carry, 10)));

    carry = Choco.sum(C, C, Choco.div(carry, 10));
    model.addConstraint(Choco.eq(G, Choco.mod(carry, 10)));

    carry = ZERO;
    
    // Add constraint of all different letters  
    model.addConstraint(Choco.allDifferent(A, B, C, D, E, F, G, H, J, K));    
    
    // Build a solver, read the model and solve it
    Solver s = new CPSolver();
    s.read(model);
    s.solve();
    long end = System.nanoTime();
    System.out.println("Laufzeit: " + ((end-start)/1000000));
    
    // Print symbol values
    System.out.println("A = " + s.getVar(A).getVal() + ", " + "B = " + s.getVar(B).getVal() + ", " + "C = " + s.getVar(C).getVal() + ", " + "D = " + s.getVar(D).getVal() + ", " + "E = " + s.getVar(E).getVal() + ", " + "F = " + s.getVar(F).getVal() + ", " + "G = " + s.getVar(G).getVal() + ", " + "H = " + s.getVar(H).getVal() + ", " + "J = " + s.getVar(J).getVal() + ", " + "K = " + s.getVar(K).getVal());
  }
  
  public static void main(String[] args){
    System.out.println("******* Finale Ausgabe *******");
  	Raetsel.solve();
  }
}
