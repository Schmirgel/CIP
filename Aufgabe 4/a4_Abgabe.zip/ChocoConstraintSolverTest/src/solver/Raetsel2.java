package solver;

import choco.Choco;
import choco.Options;
import choco.cp.model.CPModel;
import choco.cp.solver.CPSolver;
import choco.kernel.model.Model;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.Solver;

public class Raetsel2
{
    public static void main(String[] args) {
        // Build model
        Model model = new CPModel();
        
        // Declare every letter as a variable
        // Declare every letter as a variable
        IntegerVariable A = Choco.makeIntVar("A", 0, 9, Options.V_ENUM); 
        IntegerVariable B = Choco.makeIntVar("B", 0, 9, Options.V_ENUM); 
        IntegerVariable C = Choco.makeIntVar("C", 0, 9, Options.V_ENUM); 
        IntegerVariable D = Choco.makeIntVar("D", 0, 9, Options.V_ENUM); 
        IntegerVariable E = Choco.makeIntVar("E", 0, 9, Options.V_ENUM); 
        IntegerVariable F = Choco.makeIntVar("F", 0, 9, Options.V_ENUM); 
        IntegerVariable G = Choco.makeIntVar("G", 0, 9, Options.V_ENUM); 
        IntegerVariable H = Choco.makeIntVar("H", 0, 9, Options.V_ENUM); 
        IntegerVariable J = Choco.makeIntVar("J", 0, 9, Options.V_ENUM); 
        IntegerVariable K = Choco.makeIntVar("K", 0, 9, Options.V_ENUM); 
        IntegerVariable ZERO = Choco.makeIntVar("ZERO", 0, 0, Options.V_ENUM); 
        
        //Uebertraege
        IntegerVariable u1 = Choco.makeIntVar("u0", 0, 1, Options.V_ENUM);
        IntegerVariable u2 = Choco.makeIntVar("u1", 0, 1, Options.V_ENUM);
        IntegerVariable u3 = Choco.makeIntVar("u2", 0, 1, Options.V_ENUM);
        IntegerVariable u4 = Choco.makeIntVar("u3", 0, 1, Options.V_ENUM);
        IntegerVariable u5 = Choco.makeIntVar("u4", 0, 1, Options.V_ENUM);
        IntegerVariable u6 = Choco.makeIntVar("u5", 0, 1, Options.V_ENUM);
        IntegerVariable u7 = Choco.makeIntVar("u6", 0, 1, Options.V_ENUM);
        IntegerVariable u8 = Choco.makeIntVar("u7", 0, 1, Options.V_ENUM);
        IntegerVariable u9 = Choco.makeIntVar("u8", 0, 1, Options.V_ENUM);
        IntegerVariable u10 = Choco.makeIntVar("u9", 0, 1, Options.V_ENUM);
        IntegerVariable u11 = Choco.makeIntVar("u10", 0, 1, Options.V_ENUM);
        IntegerVariable u12 = Choco.makeIntVar("u11", 0, 1, Options.V_ENUM);
        IntegerVariable u13 = Choco.makeIntVar("u12", 0, 1, Options.V_ENUM);
        IntegerVariable u14 = Choco.makeIntVar("u13", 0, 1, Options.V_ENUM);
        IntegerVariable u15 = Choco.makeIntVar("u14", 0, 1, Options.V_ENUM);
        IntegerVariable u16 = Choco.makeIntVar("u15", 0, 1, Options.V_ENUM);
        IntegerVariable u17 = Choco.makeIntVar("u16", 0, 1, Options.V_ENUM);
        IntegerVariable u18 = Choco.makeIntVar("u17", 0, 1, Options.V_ENUM);
        IntegerVariable u19 = Choco.makeIntVar("u18", 0, 1, Options.V_ENUM);
        IntegerVariable u20 = Choco.makeIntVar("u19", 0, 1, Options.V_ENUM);
        IntegerVariable u21 = Choco.makeIntVar("u20", 0, 1, Options.V_ENUM);
        IntegerVariable u22 = Choco.makeIntVar("u21", 0, 1, Options.V_ENUM);
        IntegerVariable u23 = Choco.makeIntVar("u22", 0, 1, Options.V_ENUM);
        
        // Add constraints
        
        // R1
        model.addConstraint(Choco.eq(Choco.plus(G, A), Choco.plus(Choco.mult(10, u1), G)));
        model.addConstraint(Choco.eq(Choco.plus(D, E), Choco.minus(Choco.plus(Choco.mult(10, u2), G),u1)));
        model.addConstraint(Choco.eq(Choco.plus(G, E), Choco.minus(Choco.plus(Choco.mult(10, u3), A),u2)));
        model.addConstraint(Choco.eq(Choco.plus(B, B), Choco.minus(Choco.plus(Choco.mult(10, u4), C),u3)));
        model.addConstraint(Choco.lt(Choco.plus(B, B),10));
 
        // R2
        model.addConstraint(Choco.eq(Choco.plus(G, K), Choco.plus(Choco.mult(10, u5), F)));
        model.addConstraint(Choco.eq(Choco.plus(H, D), Choco.minus(Choco.plus(Choco.mult(10, u6), A),u5)));
        model.addConstraint(Choco.eq(Choco.plus(A, J), Choco.minus(Choco.plus(Choco.mult(10, u7), K),u6)));
        model.addConstraint(Choco.eq(Choco.plus(C,ZERO), Choco.minus(Choco.plus(Choco.mult(10, u8), C),u7)));
        model.addConstraint(Choco.lt(Choco.plus(C,ZERO),10));

        // R3
        model.addConstraint(Choco.eq(Choco.plus(B, B), Choco.plus(Choco.mult(10, u9), D)));
        model.addConstraint(Choco.eq(Choco.plus(C, B), Choco.minus(Choco.plus(Choco.mult(10, u10), E),u9)));
        model.addConstraint(Choco.eq(Choco.plus(F, G), Choco.minus(Choco.plus(Choco.mult(10, u11), B),u10)));
        model.addConstraint(Choco.eq(Choco.plus(F,0), Choco.minus(Choco.plus(Choco.mult(10, u12), G),u11)));
        model.addConstraint(Choco.lt(Choco.plus(F, 0),10));

        // R4
        model.addConstraint(Choco.eq(Choco.plus(G, F), Choco.plus(Choco.mult(10, u13), B)));
        model.addConstraint(Choco.eq(Choco.plus(D, A), Choco.minus(Choco.plus(Choco.mult(10, u14), C),u13)));
        model.addConstraint(Choco.eq(Choco.plus(G, K), Choco.minus(Choco.plus(Choco.mult(10, u15), F),u14)));
        model.addConstraint(Choco.eq(Choco.plus(B,C), Choco.minus(Choco.plus(Choco.mult(10, u16), F),u15)));
        model.addConstraint(Choco.lt(Choco.plus(B, C),10));
 
        // R5
        model.addConstraint(Choco.eq(Choco.plus(B, K), Choco.plus(Choco.mult(10, u17), A)));
        model.addConstraint(Choco.eq(Choco.plus(B, D), Choco.minus(Choco.plus(Choco.mult(10, u18), E),u17)));
        model.addConstraint(Choco.eq(Choco.plus(G, J), Choco.minus(Choco.plus(Choco.mult(10, u19), E),u18)));
        model.addConstraint(Choco.eq(Choco.plus(ZERO,0), Choco.minus(Choco.plus(Choco.mult(10, u20), B),u19)));

        // R6
        model.addConstraint(Choco.eq(Choco.plus(G, F), Choco.plus(Choco.mult(10, u20), D)));
        model.addConstraint(Choco.eq(Choco.plus(G, A), Choco.minus(Choco.plus(Choco.mult(10, u21), E),u20)));
        model.addConstraint(Choco.eq(Choco.plus(A, K), Choco.minus(Choco.plus(Choco.mult(10, u22), B),u21)));
        model.addConstraint(Choco.eq(Choco.plus(C,C), Choco.minus(Choco.plus(Choco.mult(10, u23), G),u22)));
        model.addConstraint(Choco.lt(Choco.plus(C, C),10));

    
        
        // Add constraint of all different letters.
        model.addConstraint(Choco.allDifferent(new IntegerVariable[]{A,B,C,D,E,F,G,H,J,K}));
        
        // Build a solver, read the model and solve it
        Solver s = new CPSolver();
        s.read(model);
        s.solve();
        
        System.out.println("A = " + s.getVar(A).getVal() + ", " + "B = " + s.getVar(B).getVal() + ", " + "C = " + s.getVar(C).getVal() + ", " + "D = " + s.getVar(D).getVal() + ", " + "E = " + s.getVar(E).getVal() + ", " + "F = " + s.getVar(F).getVal() + ", " + "G = " + s.getVar(G).getVal() + ", " + "H = " + s.getVar(H).getVal() + ", " + "J = " + s.getVar(J).getVal() + ", " + "K = " + s.getVar(K).getVal());
    }
}
